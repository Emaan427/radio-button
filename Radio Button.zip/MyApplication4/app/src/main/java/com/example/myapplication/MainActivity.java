package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button btn;
TextView txt1,txt2;
RadioGroup rg;
RadioButton grb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rg = findViewById(R.id.rg);}
    public void onclickbuttonMethod(View v){
        int selectedId = rg.getCheckedRadioButtonId();
        grb = (RadioButton) findViewById(selectedId);
        if (selectedId == -1) {
            Toast.makeText(MainActivity.this, "Nothing selected", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(MainActivity.this, grb.getText(), Toast.LENGTH_SHORT).show();
        }


    }
}